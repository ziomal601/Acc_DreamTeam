package eu.vmpay.neighborhood.help.ui.fragments.onboading

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.adapters.OnBoardingPagerAdapter
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import eu.vmpay.neighborhood.help.utils.invisibleIf
import kotlinx.android.synthetic.main.on_boarding_fragment.view.*

class OnBoardingFragment : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.on_boarding_fragment, container, false)
        rootView.apply {
            ivClose.setOnClickListener { goBack() }
            selectDot(this, 0)
            vpOnBoarding.apply {
                adapter = OnBoardingPagerAdapter(this@OnBoardingFragment)
                registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                    override fun onPageSelected(position: Int) {
                        selectDot(rootView, position)
                        rootView.llIndicators.invisibleIf(position == 2)
                        rootView.btnContinue.invisibleIf(position != 2)
                    }
                })
            }
            btnContinue.setOnClickListener { navigateTo(OnBoardingFragmentDirections.actionOnBoardingFragmentToSetUpProfileLandingFragment()) }
        }
        return rootView
    }


    private fun selectDot(rootView: View, position: Int) {
        rootView.apply {
            step1.setBackgroundColor(ContextCompat.getColor(context, if (position == 0) R.color.cobalt else R.color.lightish_blue))
            step2.setBackgroundColor(ContextCompat.getColor(context, if (position == 1) R.color.cobalt else R.color.lightish_blue))
        }
    }
}
