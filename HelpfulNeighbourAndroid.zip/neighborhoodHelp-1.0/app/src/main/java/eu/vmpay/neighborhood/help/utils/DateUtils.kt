package eu.vmpay.neighborhood.help.utils

import java.text.DateFormat
import java.util.*

object DateUtils {
    fun getDateString(timeInMillis: Long = System.currentTimeMillis()): String =
            DateFormat.getDateInstance().format(Date(timeInMillis))
}
