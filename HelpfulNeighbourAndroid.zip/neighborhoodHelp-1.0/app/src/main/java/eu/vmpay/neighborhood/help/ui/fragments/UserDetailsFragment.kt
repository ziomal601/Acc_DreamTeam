package eu.vmpay.neighborhood.help.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.adapters.TaskAdapter
import eu.vmpay.neighborhood.help.utils.showComingSoonToast
import eu.vmpay.neighborhood.help.viewmodels.DashboardViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.user_details_fragment.view.*
import org.koin.android.ext.android.inject

class UserDetailsFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: DashboardViewModel by activityViewModels { factory }
    private val taskAdapter by lazy { TaskAdapter() }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
            inflater.inflate(R.layout.user_details_fragment, container, false).apply {
                rvQuarantineList.adapter = taskAdapter
                viewModel.selectedUser.observe(viewLifecycleOwner, Observer {
                    tvTitle.text = it.userInfo.name
                    taskAdapter.submitList(it.qList)

                    btnSort.setOnClickListener { context.showComingSoonToast() }
                    btnAdd.setOnClickListener { context.showComingSoonToast() }
                    ivBack.setOnClickListener { goBack() }
                })
            }
}
