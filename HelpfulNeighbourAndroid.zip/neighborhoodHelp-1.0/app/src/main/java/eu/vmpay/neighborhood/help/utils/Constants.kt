package eu.vmpay.neighborhood.help.utils

const val MILLIS_IN_DAY = 86_400_000
const val MIN_PASSWORD_LENGTH = 8
