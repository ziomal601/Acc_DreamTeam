package eu.vmpay.neighborhood.help.viewmodels

class ShopPaymentsViewModel : BaseViewModel() {
}
