package eu.vmpay.neighborhood.help.repository.local

const val DATABASE_NAME = "neighborhood_help.db"
const val DATABASE_VERSION = 1
