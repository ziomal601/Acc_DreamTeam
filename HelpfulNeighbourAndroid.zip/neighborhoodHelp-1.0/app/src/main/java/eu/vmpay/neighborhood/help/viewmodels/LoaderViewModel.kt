package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavDirections
import eu.vmpay.neighborhood.help.repository.Repository
import eu.vmpay.neighborhood.help.ui.fragments.LoaderFragmentDirections
import eu.vmpay.neighborhood.help.utils.Event
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LoaderViewModel(repository: Repository) : BaseViewModel() {
    val navDirection = MutableLiveData<Event<NavDirections>>()

    private var navDirections: NavDirections? = null

    init {
        viewModelScope.launch {
            val fetch = async {
                val userInfo = repository.getUserInfo()
                // TODO: if profile was not set up navigate to set up profile
                if (repository.isUserSignedIn() && userInfo != null) {
                    navDirections = LoaderFragmentDirections.actionLoaderFragmentToDashboardFragment(userInfo)
                    try {
                        repository.fetchUserInfo(repository.getIdToken())
                    } catch (e: Exception) {
                        isError.value = Event(e)
                    }
                } else {
                    navDirections = LoaderFragmentDirections.actionLoaderFragmentToLoginFragment()
                }
            }
            val animation = async {
                delay(2000)
            }
            fetch.await()
            animation.await()
            mayProceed()
        }
    }

    private fun mayProceed() {
        navDirections?.let { navDirection.value = Event(it) }
    }
}
