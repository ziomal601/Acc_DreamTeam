package eu.vmpay.neighborhood.help

import android.app.Application
import eu.vmpay.neighborhood.help.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

class NHApp : Application() {

    override fun onCreate() {
        super.onCreate()
        initKoin()
    }

    private fun initKoin() {
        startKoin {
            androidLogger()
            androidContext(this@NHApp)
            modules(appModule)
        }
    }
}
