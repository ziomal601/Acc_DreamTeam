package eu.vmpay.neighborhood.help.di

import eu.vmpay.neighborhood.help.BuildConfig
import eu.vmpay.neighborhood.help.repository.Repository
import eu.vmpay.neighborhood.help.repository.local.AppDatabase
import eu.vmpay.neighborhood.help.repository.remote.AwsClient
import eu.vmpay.neighborhood.help.repository.remote.RetrofitService
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.Module
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

val appModule: Module = module {
    single { ViewModelFactory(get()) }
    single { Repository(get(), get(), get()) }
    single { AppDatabase.getInstance(androidContext()) }
    single<RetrofitService> {
        Retrofit.Builder()
                .baseUrl(BuildConfig.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(
                        OkHttpClient()
                                .newBuilder()
                                .addInterceptor(
                                        HttpLoggingInterceptor()
                                                .setLevel(if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE)
                                )
                                .build()

                )
                .build()
                .create(RetrofitService::class.java)
    }
    single { AwsClient(get()) }
}
