package eu.vmpay.neighborhood.help.models

import android.os.Parcelable
import androidx.room.*
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "users")
data class UserInfo(
        @PrimaryKey
        @SerializedName("email") val email: String,
        @SerializedName("name") val name: String,
        @SerializedName("surname") val surname: String,
        @SerializedName("phone") val phone: String,
        @SerializedName("type") val type: Int,
        @SerializedName("isQuarantine") val isQuarantine: Boolean,
        @SerializedName("isOld") val isOld: Boolean,
        @Embedded
        @SerializedName("address") val address: Address
) : Parcelable

@Parcelize
data class Address(
        @SerializedName("street") val street: String,
        @SerializedName("number") val number: String,
        @SerializedName("postalCode") val postalCode: String,
        @SerializedName("city") val city: String
) : Parcelable

enum class UserType(val type: Int) {
        CLIENT(0),
        ASSISTANT(1)
}

@Parcelize
data class UserHelpInformation(
        @Embedded
        @SerializedName("deliveryAddress") val deliveryAddress: Address,
        @SerializedName("name") val name: String,
        @SerializedName("surname") val surname: String,
        @SerializedName("phone") val phone: String,
        @SerializedName("longitude") val longitude: Double,
        @SerializedName("latitude") val latitude: Double
) : Parcelable

@Entity(tableName = "task", primaryKeys = ["userId"])
data class Task(
        @ColumnInfo(name = "userId") val userId: Long,
        @ColumnInfo(name = "type") var type: Long,
        @ColumnInfo(name = "declaredAmount") var declaredAmount: Double,
        @ColumnInfo(name = "isForOther") var isForOther: Boolean,
        @ColumnInfo(name = "isCarNeeded") var isCarNeeded: Boolean,
        @ColumnInfo(name = "isUrgent") var isUrgent: Boolean,
        @ColumnInfo(name = "status") var status: Long,
        @Embedded
        @SerializedName("userHelpInformation") var userHelpInformation: UserHelpInformation,
        @ColumnInfo(name = "title") var title: String?,
        @ColumnInfo(name = "description") var description: String?
)

data class UserTask(
        @Embedded
        val userInfo: UserInfo,
        @Relation(parentColumn = "email",
                entityColumn = "userId")
        val qList: List<Task>
)
