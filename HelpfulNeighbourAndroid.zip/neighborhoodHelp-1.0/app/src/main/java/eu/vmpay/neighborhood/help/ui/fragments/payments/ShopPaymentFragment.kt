package eu.vmpay.neighborhood.help.ui.fragments.payments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import eu.vmpay.neighborhood.help.viewmodels.ShopPaymentsViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.shop_payment_fragment.view.*
import org.koin.android.ext.android.inject

class ShopPaymentFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: ShopPaymentsViewModel by viewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.shop_payment_fragment, container, false).apply {
            paymentWebView.loadUrl("www.wp.pl")
            btnFinishPayment.setOnClickListener { navigateTo(ShopPaymentFragmentDirections.actionShopPaymentFragmentToDashboardFragment(null)) }
        }
    }
}
