package eu.vmpay.neighborhood.help

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import eu.vmpay.neighborhood.help.utils.goneIf
import kotlinx.android.synthetic.main.main_activity.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
    }

    fun showLoader(shouldShow: Boolean) {
        pbLoader.goneIf(!shouldShow)
        loaderBackground.goneIf(!shouldShow)
    }
}
