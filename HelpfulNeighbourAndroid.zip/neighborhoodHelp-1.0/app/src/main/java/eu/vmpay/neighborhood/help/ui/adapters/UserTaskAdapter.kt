package eu.vmpay.neighborhood.help.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.models.UserTask
import kotlinx.android.synthetic.main.item_user.view.*

class UserTaskAdapter(
        private val onClick: (UserTask) -> Unit
) : ListAdapter<UserTask, UserTaskAdapter.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<UserTask>() {
            override fun areItemsTheSame(oldItem: UserTask, newItem: UserTask) = oldItem.userInfo.email == newItem.userInfo.email
            override fun areContentsTheSame(oldItem: UserTask, newItem: UserTask) = oldItem == newItem
        }
    }

    class ViewHolder(private val userView: View) : RecyclerView.ViewHolder(userView) {
        fun bind(item: UserTask, onClick: (UserTask) -> Unit) {
            userView.apply {
                setOnClickListener { onClick(item) }
                tvName.text = item.userInfo.name
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onClick)
    }
}
