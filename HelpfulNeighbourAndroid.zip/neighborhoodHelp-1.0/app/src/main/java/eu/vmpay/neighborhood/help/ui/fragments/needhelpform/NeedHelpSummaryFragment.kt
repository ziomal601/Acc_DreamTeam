package eu.vmpay.neighborhood.help.ui.fragments.needhelpform

import android.icu.util.Currency
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import eu.vmpay.neighborhood.help.viewmodels.NeedHelpFormViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.need_help_summary_fragment.view.*
import org.koin.android.ext.android.inject
import java.util.*

class NeedHelpSummaryFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: NeedHelpFormViewModel by activityViewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.need_help_summary_fragment, container, false).apply {

            viewModel.task?.let {
                title.text = it.title
                if (it.isUrgent) {
                    isImportantChip.visibility = View.VISIBLE
                }
                selectedType.text = resources.getString(viewModel.getType(it.type.toInt()))
                if (it.isCarNeeded) {
                    carNeededCip.visibility = View.VISIBLE
                }
                desc.text = it.description
                if (it.declaredAmount > 0) {
                    var currency = Currency.getInstance(Locale.getDefault())
                    val symbol = currency.getSymbol()
                    amount.text = "${it.declaredAmount} $symbol"
                }
            }

            btnConfirm.setOnClickListener {
                navigateTo(NeedHelpSummaryFragmentDirections.actionNeedHelpSummaryFragmentToShopPaymentFragment())

            }
        }
    }
}
