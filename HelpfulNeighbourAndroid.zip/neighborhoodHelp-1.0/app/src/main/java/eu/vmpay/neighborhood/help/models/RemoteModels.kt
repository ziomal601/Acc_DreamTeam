package eu.vmpay.neighborhood.help.models

import com.google.gson.annotations.SerializedName

data class PostUserInfo(
        @SerializedName("name") val name: String,
        @SerializedName("surname") val surname: String,
        @SerializedName("phone") val phone: String,
        @SerializedName("type") val type: Int = 0,
        @SerializedName("isOld") val isOld: Boolean = false,
        @SerializedName("isQuarantine") var isQuarantine: Boolean = false,
        @SerializedName("address") var address: Address? = null
)
