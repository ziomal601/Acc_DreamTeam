package eu.vmpay.neighborhood.help.repository.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import eu.vmpay.neighborhood.help.models.Task
import eu.vmpay.neighborhood.help.models.UserInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

@Database(entities = [UserInfo::class, Task::class],
        version = DATABASE_VERSION)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun tasksDao(): TasksDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                            context.applicationContext,
                            AppDatabase::class.java, DATABASE_NAME
                    )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            populateDB(context)
                        }

                        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
                            super.onDestructiveMigration(db)
                            populateDB(context)
                        }
                    })
                    .build()
        }

        private fun populateDB(context: Context) {
            prepopulateUsers(context)
            prepopulateTasks(context)
        }

        private fun prepopulateTasks(context: Context) {

            GlobalScope.launch(Dispatchers.IO) {
                // getInstance(context).tasksDao().insert(taskList)
            }
        }

        private fun prepopulateUsers(context: Context) {
//            val userList = arrayOf(
//                    UserInfo(0, "Tomasz", "tomasz.malski@gmail.com"),
//                    UserInfo(1, "Andrian", "adriano100417@gmail.com"),
//                    UserInfo(2, "Eugen", "jekahy@gmail.com"),
//                    UserInfo(3, "Andrii_Andrii_Andrii_Andrii_Andrii", "vmpay.eu@gmail.com")
//            )
//            GlobalScope.launch(Dispatchers.IO) {
//                getInstance(context).userDao().insert(userList)
//            }
        }
    }
}
