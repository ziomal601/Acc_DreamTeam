var pg = require("pg")
var Pool = require("pg").Pool

exports.handler = async (event) => {
 
 var mail = event.requestContext.authorizer.claims.email;
 var body = JSON.parse(event.body);
 
    // Load the AWS SDK
    var AWS = require('aws-sdk'),
        region = "eu-west-1",
        secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
    // Create a Secrets Manager client
    var client = new AWS.SecretsManager({
        region: region
    });

    var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
    var secret = await getSecretPromise
    var secretString = JSON.parse(secret.SecretString)
    const pool = new Pool({
      user: secretString.username,
      host:secretString.host,
      database: secretString.engine,
      password: secretString.password,
      port: secretString.port
    });
 
 var values2 = ['','','',''];
 let addressID = await pool.query('insert into adress(street, number, city, postalcode) values ($1, $2, $3, $4) returning id;', values2);
 
 var values = [mail,body.name,body.surname,body.phone,body.type,body.isOld,body.isQuarantine,addressID.rows[0].id];
 var res = await pool.query('insert into users(mail, name, surname, phone, isvolunteer, isold, isquarantined, adressid) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', values)
 console.log('ok: ' + JSON.stringify(res));
 const response = {
        statusCode: 200,
        body: JSON.stringify('OK'),
    }; 
 return response;
};