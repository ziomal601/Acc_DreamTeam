var pg = require("pg")
var Pool = require("pg").Pool

exports.handler = async (event) => {
 
 var mail = event.requestContext.authorizer.claims.email;
    // Load the AWS SDK
    var AWS = require('aws-sdk'),
        region = "eu-west-1",
        secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
    // Create a Secrets Manager client
    var client = new AWS.SecretsManager({
        region: region
    });

    var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
    var secret = await getSecretPromise
    var secretString = JSON.parse(secret.SecretString)
    const pool = new Pool({
      user: secretString.username,
      host:secretString.host,
      database: secretString.engine,
      password: secretString.password,
      port: secretString.port
    });
 
 var x = await pool.query("SELECT * from users u JOIN adress a on u.adressid=a.id where mail like $1 LIMIT 1;", [mail]);
 var row = x.rows[0];
 var user = {
  "email": row.mail,
  "name": row.name,
  "surname": row.surname,
  "phone": row.phone,
  "type": row.isvolunteer + 0,
  "isQuarantine": row.isquarantined,
  "isOld": row.isold,
  "address":{
   "addressID": row.addressid,
   "street": row.street,
   "number": row.number,
   "city": row.city,
   "postalCode": row.postalcode,
   "apartment": row.appartment
  }
 }
  
 const response = {
        statusCode: 200,
        body: JSON.stringify(user),
    }; 
 return response;
 
};