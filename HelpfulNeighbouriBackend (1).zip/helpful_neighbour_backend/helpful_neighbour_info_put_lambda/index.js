var pg = require("pg")
var Pool = require("pg").Pool

exports.handler = async (event) => {
 
 var mail = event.requestContext.authorizer.claims.email;
 var body = JSON.parse(event.body);
 var address = body.address;
 
	// Load the AWS SDK
	var AWS = require('aws-sdk'),
		region = "eu-west-1",
		secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
	// Create a Secrets Manager client
	var client = new AWS.SecretsManager({
		region: region
	});

	var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
	var secret = await getSecretPromise
	var secretString = JSON.parse(secret.SecretString)
	const pool = new Pool({
	  user: secretString.username,
	  host:secretString.host,
	  database: secretString.engine,
	  password: secretString.password,
	  port: secretString.port
	});
 
 var values = [address.street,address.number,address.city,address.postalCode,mail];
 let addressID = await pool.query('update adress set street=$1, number=$2, city=$3, postalcode=$4 where id = (SELECT adressid from users where mail like $5);', values);
 
 var values2 = [body.name,body.surname,body.phone,body.type,body.isOld,body.isQuarantine,mail];
 var res = await pool.query('update users set name=$1, surname=$2, phone=$3, isvolunteer=$4, isold=$5, isquarantined=$6 where mail like $7;', values2)
 console.log('ok' + res.rowcount)
  const response = {
        statusCode: 200,
        body: JSON.stringify('OK'),
    }; 
 return response;
};