var pg = require("pg");
var Pool = require("pg").Pool;

exports.handler = async event => {
    // Load the AWS SDK
    var AWS = require('aws-sdk'),
        region = "eu-west-1",
        secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
    // Create a Secrets Manager client
    var client = new AWS.SecretsManager({
        region: region
    });

    var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
    var secret = await getSecretPromise
    var secretString = JSON.parse(secret.SecretString)
    const pool = new Pool({
      user: secretString.username,
      host:secretString.host,
      database: secretString.engine,
      password: secretString.password,
      port: secretString.port
    });
  
  var selectQuery = "SELECT a.id as activity_id, u.id as uid, addr.id as addrid, * FROM activity a LEFT JOIN users u on a.userid=u.id LEFT JOIN adress addr on a.adressid=addr.id"; 
  var queryResult = await pool.query(selectQuery);
  var response = queryResult.rows.map(function(result, index) {
    var responseItem = {
      id: result["activity_id"],
      type: result["isvolunteer"] ? 1 : 0,
      declaredAmount: result["declaredamount"],
      isForOther: result["isforother"],
      isCarNeeded: result["iscarneeded"],
      title: result["title"],
      description: result["description"],
      status: result["status"],
      userHelpInformation: {
        deliveryAddress: {
          street: result["street"],
          number: result["number"],
          postalCode: result["postalcode"],
          city: result["city"]
        },
        longitude: result["longitude"],
        latitude: result["latitude"],
        name: result["name"],
        surname: result["surname"],
        phone: result["phone"]
      },
      isUrgent: result["isurgent"]
    };
    return responseItem;
  });

  return {
    statusCode: 200,
    body: JSON.stringify(response)
  };
};
