var Pool = require("pg").Pool

exports.handler = async (event) => {
    // Load the AWS SDK
    var AWS = require('aws-sdk'),
        region = "eu-west-1",
        secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
    // Create a Secrets Manager client
    var client = new AWS.SecretsManager({
        region: region
    });

    var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
    var secret = await getSecretPromise
    var secretString = JSON.parse(secret.SecretString)
    const pool = new Pool({
      user: secretString.username,
      host:secretString.host,
      database: secretString.engine,
      password: secretString.password,
      port: secretString.port
    });
	
  event = {
        title: "tytull",
        description: "description",
        declaredAmount: 150,
        isForOther: true,
        isCarNeeded: true,
        status: 0,
        isUrgent: true
    }

  // var eventBody = JSON.parse(event.body);
  var eventBody = event
  var userEmail = "test@test.pl"
  // var userEmail = event.requestContext.authorizer.claims.email;


  var selectUserIdQuery = `(select u.id from users u where mail = '${userEmail}')`;
  var selectAddressIdQuery = `(select u.adressid from users u where mail = '${userEmail}')`;
  var values = [eventBody.title, eventBody.description, eventBody.declaredAmount, eventBody.isForOther, eventBody.isCarNeeded, eventBody.status, eventBody.isUrgenty]
  var insertQuery = `insert into activity (title, description, declaredamount, isforother, iscarneeded, status, isurgent, adressid, userid) VALUES ($1, $2, $3, $4, $5, $6, $7, ${selectAddressIdQuery}, ${selectUserIdQuery}) returning *`;
  
  var queryResult = await pool.query(insertQuery, values);
  console.log(queryResult)
  
	const response = {
		statusCode: 200,
		body: JSON.stringify('OK'),
	};
	return response;
};
