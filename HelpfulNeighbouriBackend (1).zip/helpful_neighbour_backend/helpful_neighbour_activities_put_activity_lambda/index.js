var pg = require("pg")
var Pool = require("pg").Pool

exports.handler = async (event) => {
 
 var mail = event.requestContext.authorizer.claims.email;
// var body = JSON.parse(event.body);
 const body = event.body;
 
    // Load the AWS SDK
    var AWS = require('aws-sdk'),
        region = "eu-west-1",
        secretName = "arn:aws:secretsmanager:eu-west-1:572931979401:secret:database-password-xlPtsq"
    // Create a Secrets Manager client
    var client = new AWS.SecretsManager({
        region: region
    });

    var getSecretPromise = client.getSecretValue({SecretId: secretName}).promise();
    var secret = await getSecretPromise
    var secretString = JSON.parse(secret.SecretString)
    const pool = new Pool({
      user: secretString.username,
      host:secretString.host,
      database: secretString.engine,
      password: secretString.password,
      port: secretString.port
    });
 
 //activity
 var values = [body.status, body.title ,body.description, body.declaredAmount,
 body.actualAmount,body.isForOther,body.isCarNeeded,body.isUrgent,
 body.deliveryDate,body.deliveryTimeFrom,body.deliveryTimeTo,body.note,body.activityId];
 let addressID = await pool.query(`update activity set status = $1, title=$2, description=$3, declaredamount=$4,
 actualamount=$5,isforother=$6,iscarneeded=$7,isurgent=$8,
 deliverydate=$9,deliverytimefrom=$10,deliverytimeto=$11,note=$12
 where id = $13;`, values);
console.log("doszlo")
 
 //address
 let valuesaddress = [body.address.street,body.address.number,body.address.city,body.address.postalCode,body.activityId];
 let addressupdate = await pool.query('update adress set street=$1, number=$2, city=$3, postalcode=$4 where id = (SELECT adressid from activity where id= $5);', valuesaddress);
 
 
 

 return {
        statusCode: 200,
        body: JSON.stringify('OK'),
    }; 
};