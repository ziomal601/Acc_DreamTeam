package eu.vmpay.neighborhood.help

import eu.vmpay.neighborhood.help.utils.differenceInDays
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExtensionsTest {

    @Test
    fun differenceInDaysTest() {
        val first = 1584222043000 // 14.03.2020 9:40
        val second = 1584222208000 // 14.03.2020 9:43
        val third = 1584267217000 // 15.03.2020 10:13
        val fourth = 1584532800000 // 18.03.2020 12:00
        assertEquals(0, first.differenceInDays(second))
        assertEquals(0, first.differenceInDays(third))
        assertEquals(3, first.differenceInDays(fourth))
    }
}