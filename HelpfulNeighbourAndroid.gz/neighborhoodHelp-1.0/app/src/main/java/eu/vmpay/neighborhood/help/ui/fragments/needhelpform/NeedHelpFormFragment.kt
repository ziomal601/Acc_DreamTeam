package eu.vmpay.neighborhood.help.ui.fragments.needhelpform

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.models.Address
import eu.vmpay.neighborhood.help.models.Task
import eu.vmpay.neighborhood.help.models.UserHelpInformation
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import eu.vmpay.neighborhood.help.viewmodels.NeedHelpFormViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.need_help_form_fragment.view.*
import org.koin.android.ext.android.inject

class NeedHelpFormFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: NeedHelpFormViewModel by activityViewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.need_help_form_fragment, container, false).apply {

            btnNextScreen.setOnClickListener {
                viewModel.task = Task(
                    0,
                    viewModel.getTypeID(typeSelection),
                    if (amout.text.isNotEmpty()) amout.text.toString().toDouble() else 0.0,
                    forOthers.isSelected,
                    carNeeded.isSelected,
                    isImportant.isSelected,
                    0,
                    UserHelpInformation(
                        Address("Piotrkowska", "190", "92-040", "Lodz"),
                        "Alina",
                        "Alinowska",
                        "123-123-123",
                        52.123, 19.123
                    ),
                    title.text.toString(),
                    desc.text.toString()

                )
                navigateTo(NeedHelpFormFragmentDirections.actionNeedHelpFormFragmentToNeedHelpSummaryFragment())
            }
        }
    }


}
