package eu.vmpay.neighborhood.help.utils

import android.content.Context
import android.view.View
import android.widget.Toast
import kotlin.math.abs

fun Long.differenceInDays(second: Long = System.currentTimeMillis()): Long {
    val millis = abs(this - second)
    return millis / MILLIS_IN_DAY
}

fun Context.showComingSoonToast() {
    Toast.makeText(this, "Coming soon...", Toast.LENGTH_SHORT).show()
}

fun View.isVisible(): Boolean = visibility == View.VISIBLE

fun View.visible() {
    visibility = View.VISIBLE
}

fun View.invisible() {
    visibility = View.INVISIBLE
}

fun View.gone() {
    visibility = View.GONE
}

fun View.switchGoneVisible() {
    if (visibility == View.VISIBLE) gone() else visible()
}

fun View.switchInvisibleVisible() {
    if (visibility == View.VISIBLE) invisible() else visible()
}

fun View.invisibleIf(shouldBeInvisible: Boolean) {
    if (shouldBeInvisible) invisible() else visible()
}

fun View.goneIf(shouldBeGone: Boolean) {
    if (shouldBeGone) gone() else visible()
}

fun View.setEnableIf(shouldEnable: Boolean) {
    isEnabled = shouldEnable
}

fun String.isMatchEmail(): Boolean = Regex(
        "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}"
                + "\\@"
                + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}"
                + "(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{1,})"
).matches(this)

fun String.isPasswordValid(): Boolean = length >= MIN_PASSWORD_LENGTH

fun String.isNameValid(): Boolean = isNotBlank()
