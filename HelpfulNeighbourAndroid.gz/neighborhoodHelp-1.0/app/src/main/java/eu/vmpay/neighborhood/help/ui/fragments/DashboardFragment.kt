package eu.vmpay.neighborhood.help.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.adapters.UserTaskAdapter
import eu.vmpay.neighborhood.help.viewmodels.DashboardViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.dashboard_fragment.view.*
import org.koin.android.ext.android.inject

class DashboardFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: DashboardViewModel by activityViewModels { factory }
    private val userQuarantineAdapter by lazy {
        UserTaskAdapter {
            viewModel.selectUser(it)
            navigateTo(DashboardFragmentDirections.actionDashboardFragmentToUserDetailsFragment())
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
            inflater.inflate(R.layout.dashboard_fragment, container, false).apply {
                rvQuarantineList.apply {
                    adapter = userQuarantineAdapter
                    layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
                }
                btnNeedHelp.setOnClickListener {
                    navigateTo(DashboardFragmentDirections.actionDashboardFragmentToNeedHelpFormFragment())
                }
                btnSignOut.setOnClickListener { viewModel.signOut() }

                with(viewModel) {
                    currentDate.observe(viewLifecycleOwner, Observer {
                        tvTitle.text = getString(R.string.current_date, it)
                    })
                    totalDaysPerPersons.observe(viewLifecycleOwner, Observer {
                        tvSubTitle.text = getString(R.string.total_stats, it.first, it.second)
                    })
                    userQList.observe(viewLifecycleOwner, Observer {
                        userQuarantineAdapter.submitList(it)
                    })
                    signOutSuccess.observe(viewLifecycleOwner, Observer {
                        it.getContentIfNotHandled()?.let {
                            navigateTo(DashboardFragmentDirections.actionDashboardFragmentToLoginFragment())
                        }
                    })
                }
            }

}
