package eu.vmpay.neighborhood.help.repository.local

import androidx.room.Dao
import androidx.room.Query
import eu.vmpay.neighborhood.help.models.Task
import kotlinx.coroutines.flow.Flow

@Dao
abstract class TasksDao : BaseDao<Task>() {

    @Query("SELECT * FROM task WHERE userId LIKE :uid")
    abstract fun getTaskByUser(uid: Long): Flow<List<Task>>

    @Query("DELETE FROM task")
    abstract suspend fun deleteAll()
}
