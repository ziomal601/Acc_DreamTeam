package eu.vmpay.neighborhood.help.repository.remote

import eu.vmpay.neighborhood.help.models.PostUserInfo
import eu.vmpay.neighborhood.help.models.UserInfo
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.PUT

interface RetrofitService {

    @GET("test/user")
    suspend fun getUserInfo(@Header("token") token: String): UserInfo

    @GET("test/echo/123")
    suspend fun testAuth(@Header("token") token: String): String

    @POST("test/user")
    suspend fun postUserInfo(@Header("token") token: String, @Body userInfo: PostUserInfo): String

    @PUT("test/user")
    suspend fun putUserInfo(@Header("token") token: String, @Body userInfo: PostUserInfo): String
}