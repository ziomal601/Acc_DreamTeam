package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import eu.vmpay.neighborhood.help.utils.Event

abstract class BaseViewModel : ViewModel() {
    val isLoading = MutableLiveData<Boolean>()
    val isError = MutableLiveData<Event<Throwable>>()
}
