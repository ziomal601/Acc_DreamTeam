package eu.vmpay.neighborhood.help.ui.fragments.registration

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import kotlinx.android.synthetic.main.set_up_profile_assistant_payment_fragment.view.*

class SetUpProfileAssistantPaymentFragment : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.set_up_profile_assistant_payment_fragment, container, false).apply {
            btnProceed.setOnClickListener { navigateTo(SetUpProfileAssistantPaymentFragmentDirections.actionSetUpProfileAssistantPaymentFragmentToRequestPermissionFragment()) }
        }
    }
}
