package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavDirections
import com.amazonaws.mobile.client.results.SignInState
import com.amazonaws.services.cognitoidentityprovider.model.UserNotConfirmedException
import eu.vmpay.neighborhood.help.repository.Repository
import eu.vmpay.neighborhood.help.ui.fragments.LoginFragmentDirections
import eu.vmpay.neighborhood.help.utils.Event
import kotlinx.coroutines.launch

class LoginViewModel(private val repository: Repository) : BaseViewModel() {

    val loginSuccess = MutableLiveData<Event<NavDirections>>()

    fun logInWithEmail(email: String, password: String) {
        isLoading.value = true
        viewModelScope.launch {
            try {
                val signInResult = repository.signInWithEmailPassword(email, password)
                when (signInResult.signInState) {
                    SignInState.DONE -> {
                        val userInfo = repository.fetchUserInfo(repository.getIdToken())
                        // TODO: if profile was not set up navigate to set up profile
                        loginSuccess.value = Event(LoginFragmentDirections.actionLoginFragmentToDashboardFragment(userInfo))
                    }
                    SignInState.SMS_MFA,
                    SignInState.PASSWORD_VERIFIER,
                    SignInState.CUSTOM_CHALLENGE,
                    SignInState.DEVICE_SRP_AUTH,
                    SignInState.DEVICE_PASSWORD_VERIFIER,
                    SignInState.ADMIN_NO_SRP_AUTH,
                    SignInState.NEW_PASSWORD_REQUIRED -> throw Exception("SignIn Failed ${signInResult.signInState}")
                    else -> throw Exception("SignIn Failed ${signInResult.signInState}")
                }
            } catch (e: Exception) {
                if (e is UserNotConfirmedException)
                    loginSuccess.value = Event(LoginFragmentDirections.actionLoginFragmentToNumberVerificationFragment(email))
                else isError.value = Event(e)
            } finally {
                isLoading.value = false
            }
        }
    }
}
