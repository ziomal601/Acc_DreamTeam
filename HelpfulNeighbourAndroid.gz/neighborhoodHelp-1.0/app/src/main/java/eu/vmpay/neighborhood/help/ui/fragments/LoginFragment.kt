package eu.vmpay.neighborhood.help.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.amazonaws.services.cognitoidentity.model.NotAuthorizedException
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.utils.isMatchEmail
import eu.vmpay.neighborhood.help.utils.isPasswordValid
import eu.vmpay.neighborhood.help.utils.setEnableIf
import eu.vmpay.neighborhood.help.viewmodels.LoginViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.fragment_login.view.*
import org.koin.android.ext.android.inject

class LoginFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: LoginViewModel by viewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
                .apply {
                    btnLogin.setOnClickListener { viewModel.logInWithEmail(etEmail.text.toString(), etPassword.text.toString()) }
                    btnRegister.setOnClickListener { navigateTo(LoginFragmentDirections.actionLoginFragmentToRegistrationFragment()) }
                    etEmail.addTextChangedListener {
                        tilEmail.error = if (it.toString().isMatchEmail() || it?.isEmpty() == true) null else getString(R.string.invalid_data)
                        btnLogin.setEnableIf(areCredentialsValid(it.toString(), etPassword.text.toString()))
                    }
                    etPassword.addTextChangedListener {
                        tilPassword.error = if (it.toString().isPasswordValid() || it?.isEmpty() == true) null else getString(R.string.invalid_data)
                        btnLogin.setEnableIf(areCredentialsValid(etEmail.text.toString(), it.toString()))
                    }
                    etPassword.setOnEditorActionListener { _, actionId, _ ->
                        if (actionId == EditorInfo.IME_ACTION_SEND) {
                            val email = etEmail.text.toString()
                            val password = etPassword.text.toString()
                            if (areCredentialsValid(email, password)) {
                                viewModel.logInWithEmail(email, password)
                                false
                            } else {
                                Toast.makeText(context, R.string.invalid_credentials, Toast.LENGTH_LONG).show()
                                true
                            }
                        } else {
                            false
                        }
                    }

                    with(viewModel) {
                        loginSuccess.observe(viewLifecycleOwner, Observer {
                            it.getContentIfNotHandled()?.let { navigateTo(it) }
                        })
                        isLoading.observe(viewLifecycleOwner, Observer {
                            showActivityLoader(it)
                        })
                        isError.observe(viewLifecycleOwner, Observer {
                            it.getContentIfNotHandled()?.let {
                                if (it is NotAuthorizedException) tilPassword.error = getString(R.string.wrong_email_or_password)
                                else handleDebugError(it)
                            }
                        })
                    }
                }
    }

    private fun areCredentialsValid(email: String, password: String) =
            email.isMatchEmail() && password.isPasswordValid()
}
