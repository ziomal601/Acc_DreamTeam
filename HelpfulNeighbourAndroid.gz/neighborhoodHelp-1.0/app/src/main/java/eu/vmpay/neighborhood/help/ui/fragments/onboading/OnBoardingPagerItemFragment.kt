package eu.vmpay.neighborhood.help.ui.fragments.onboading

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import kotlinx.android.synthetic.main.on_boarding_item_fragment.view.*

class OnBoardingPagerItemFragment(private val position: Int) : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.on_boarding_item_fragment, container, false).apply {
            if (position == 1) {
                tvTitle.text = getString(R.string.how_to_apply)
                tvDescription.text = getString(R.string.on_boarding_step_2_description)
                tvDescription2.text = getString(R.string.on_boarding_step_2_description_2)
                ivHeroImage.setImageResource(R.drawable.on_boarding_step_2)
            } else if (position == 2) {
                tvTitle.text = getString(R.string.how_to_help)
                tvDescription.text = getString(R.string.on_boarding_step_3_description)
                tvDescription2.text = getString(R.string.on_boarding_step_3_description_2)
                ivHeroImage.setImageResource(R.drawable.on_boarding_step_3)
            }
        }
    }
}
