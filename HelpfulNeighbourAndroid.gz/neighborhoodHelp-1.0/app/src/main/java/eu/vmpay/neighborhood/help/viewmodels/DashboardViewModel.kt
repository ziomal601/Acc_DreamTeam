package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import eu.vmpay.neighborhood.help.models.UserTask
import eu.vmpay.neighborhood.help.repository.Repository
import eu.vmpay.neighborhood.help.utils.DateUtils
import eu.vmpay.neighborhood.help.utils.Event
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class DashboardViewModel(private val repository: Repository) : BaseViewModel() {

    val userQList = MutableLiveData<List<UserTask>>()
    val currentDate = MutableLiveData<String>()
    val totalDaysPerPersons = MutableLiveData<Pair<Long, Int>>()
    val selectedUser = MutableLiveData<UserTask>()
    val signOutSuccess = MutableLiveData<Event<Boolean>>()

    init {
        repository.getUserTasks()
                .onStart { isLoading.value = true }
                .onCompletion { isLoading.value = false }
                .catch {
                    isError.value = Event(it)
                }
                .onEach {

                currentDate.value = DateUtils.getDateString()
                    userQList.value = it
                }
                .launchIn(viewModelScope)
    }

    fun selectUser(userTask: UserTask) {
        selectedUser.value = userTask
    }

    fun signOut() {
        isLoading.value = true
        viewModelScope.launch {
            try {
                repository.cleanDatabase()
                signOutSuccess.value = Event(repository.signOut())
            } catch (e: Exception) {
                isError.value = Event(e)
                signOutSuccess.value = Event(false)
            } finally {
                isLoading.value = false
            }
        }
    }
}
