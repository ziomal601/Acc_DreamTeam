package eu.vmpay.neighborhood.help.repository.remote

import android.content.Context
import android.util.Log
import com.amazonaws.mobile.client.AWSMobileClient
import com.amazonaws.mobile.client.Callback
import com.amazonaws.mobile.client.UserState
import com.amazonaws.mobile.client.UserStateDetails
import com.amazonaws.mobile.client.UserStateListener
import com.amazonaws.mobile.client.results.SignInResult
import com.amazonaws.mobile.client.results.SignUpResult
import com.amazonaws.mobile.client.results.UserCodeDeliveryDetails
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine


class AwsClient(context: Context) {
    private val client = AWSMobileClient.getInstance()

    init {
        client.initialize(context, object : Callback<UserStateDetails> {
            override fun onResult(result: UserStateDetails?) {
                Log.i("AwsClient", "onResult: ${result?.userState}")
            }

            override fun onError(e: Exception?) {
                Log.e("AwsClient", "Initialization error $e")
            }
        })
    }

    fun isUserSignedIn() = client.isSignedIn

    fun getIdToken(): String = client.tokens.idToken.tokenString

    suspend fun signIn(email: String, password: String): SignInResult {
        return suspendCoroutine {
            client.signIn(email, password, null, object : Callback<SignInResult> {
                override fun onResult(result: SignInResult) {
                    Log.d("AwsClient", "Sign-in callback state: " + result.signInState)
                    it.resume(result)
                }

                override fun onError(e: java.lang.Exception) {
                    Log.e("AwsClient", "signIn error $e")
                    it.resumeWithException(e)
                }
            })
        }
    }

    suspend fun signOut(): Boolean {
        return suspendCoroutine { continuation ->
            var signInListener: UserStateListener? = null
            signInListener = UserStateListener {
                Log.d("AwsClient", "signOut user state ${it.userState}")
                when (it.userState) {
                    UserState.SIGNED_OUT_FEDERATED_TOKENS_INVALID,
                    UserState.SIGNED_OUT_USER_POOLS_TOKENS_INVALID,
                    UserState.SIGNED_OUT -> continuation.resume(true)
                    else -> continuation.resumeWithException(Throwable(it.userState.name))
                }
                signInListener?.let { client.removeUserStateListener(it) }
            }
            client.addUserStateListener(signInListener)
            client.signOut()
        }
    }

    suspend fun signUp(email: String, password: String): UserCodeDeliveryDetails? {
        return suspendCoroutine {
            val attributes = mapOf(Pair("email", email))
            client.signUp(email, password, attributes, null, object : Callback<SignUpResult> {
                override fun onResult(signUpResult: SignUpResult) {
                    Log.d("AwsClient", "Sign-up callback state: " + signUpResult.confirmationState)
                    if (!signUpResult.confirmationState) {
                        val details: UserCodeDeliveryDetails = signUpResult.userCodeDeliveryDetails
                        Log.d("AwsClient", "Confirm sign-up with: ${details.destination}")
                        it.resume(details)
                    } else {
                        // Sign-up done
                        it.resume(null)
                    }
                }

                override fun onError(e: java.lang.Exception) {
                    Log.e("AwsClient", "Sign-up error $e")
                    it.resumeWithException(e)
                }
            })
        }
    }

    private fun printLogs() {
        if (client.isSignedIn) {
            Log.d("AwsClient", "accessToken ${client.tokens.accessToken.tokenString}")
            Log.d("AwsClient", "idToken ${client.tokens.idToken.tokenString}")
            Log.d("AwsClient", "refreshToken ${client.tokens.refreshToken.tokenString}")
        } else Log.d("AwsClient", "NOT SIGNED IN")
    }
}
