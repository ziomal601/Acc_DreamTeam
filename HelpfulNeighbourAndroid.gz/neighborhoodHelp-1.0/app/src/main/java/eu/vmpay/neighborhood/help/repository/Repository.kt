package eu.vmpay.neighborhood.help.repository

import eu.vmpay.neighborhood.help.models.PostUserInfo
import eu.vmpay.neighborhood.help.repository.local.AppDatabase
import eu.vmpay.neighborhood.help.repository.remote.AwsClient
import eu.vmpay.neighborhood.help.repository.remote.RetrofitService

/**
 * If method starts with 'fetch' that means app requests data from remote server
 * If method starts with 'get' that means app requests data from local database
 */
class Repository(
        private val awsClient: AwsClient,
        private val retrofitService: RetrofitService,
        private val appDatabase: AppDatabase
) {
    fun getUserTasks() = appDatabase.userDao().getUserTaskList()

    suspend fun getUserInfo() = appDatabase.userDao().getUserInfo()

    suspend fun fetchUserInfo(token: String) =
            retrofitService.getUserInfo(token)
                    .also { appDatabase.userDao().insert(it) }

    suspend fun signUp(email: String, password: String) = awsClient.signUp(email, password)

    suspend fun postUserInfo(token: String, postUserInfo: PostUserInfo) = retrofitService.postUserInfo(token, postUserInfo)

    suspend fun putUserInfo(token: String, postUserInfo: PostUserInfo) = retrofitService.putUserInfo(token, postUserInfo)

    suspend fun signInWithEmailPassword(email: String, password: String) = awsClient.signIn(email, password)

    suspend fun signOut() = awsClient.signOut()

    fun isUserSignedIn() = awsClient.isUserSignedIn()

    fun getIdToken() = awsClient.getIdToken()

    suspend fun testAuth(accessToken: String): String = retrofitService.testAuth(accessToken)

    suspend fun cleanDatabase() {
        with(appDatabase) {
            userDao().deleteAll()
            tasksDao().deleteAll()
        }
    }
}
