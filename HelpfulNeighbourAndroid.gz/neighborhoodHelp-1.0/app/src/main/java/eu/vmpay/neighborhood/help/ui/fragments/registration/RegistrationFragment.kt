package eu.vmpay.neighborhood.help.ui.fragments.registration

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.ui.fragments.BaseFragment
import eu.vmpay.neighborhood.help.utils.isMatchEmail
import eu.vmpay.neighborhood.help.utils.isNameValid
import eu.vmpay.neighborhood.help.utils.isPasswordValid
import eu.vmpay.neighborhood.help.utils.setEnableIf
import eu.vmpay.neighborhood.help.viewmodels.RegistrationViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import kotlinx.android.synthetic.main.registration_fragment.*
import kotlinx.android.synthetic.main.registration_fragment.view.*
import org.koin.android.ext.android.inject

class RegistrationFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: RegistrationViewModel by activityViewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.registration_fragment, container, false).apply {
            etName.addTextChangedListener {
                tilName.error = if (it.toString().isNameValid()) null else getString(R.string.invalid_data)
                validateFields()
            }
            etSurname.addTextChangedListener {
                tilSurname.error = if (it.toString().isNameValid()) null else getString(R.string.invalid_data)
                validateFields()
            }
            etEmail.addTextChangedListener {
                tilEmail.error = if (it.toString().isMatchEmail()) null else getString(R.string.invalid_data)
                validateFields()
            }
            etNumber.addTextChangedListener {
                tilNumber.error = if (it.toString().isNameValid()) null else getString(R.string.invalid_data)
                validateFields()
            }
            etPassword.addTextChangedListener {
                tilPassword.error = if (it.toString().isPasswordValid()) null else getString(R.string.invalid_data)
                validateFields()
            }
            etPasswordRepeat.addTextChangedListener {
                tilPasswordRepeat.error = if (it.toString().isPasswordValid() && it.toString() == etPassword.text.toString()) null
                else if (it.toString().isPasswordValid() && it.toString() != etPassword.text.toString()) getString(R.string.password_not_match)
                else getString(R.string.invalid_data)
                validateFields()
            }
            cbEula.setOnCheckedChangeListener { _, _ -> validateFields() }
            btnFinishRegistration.setOnClickListener {
                viewModel.createAccount(
                        etEmail.text.toString(),
                        etPassword.text.toString(),
                        etName.text.toString(),
                        etSurname.text.toString(),
                        etNumber.text.toString()
                )
            }
            ivBack.setOnClickListener { goBack() }
            ivBack.setOnLongClickListener {

            navigateTo(RegistrationFragmentDirections.actionRegistrationFragmentToOnBoardingFragment())
                true
            }

            with(viewModel) {
                navDirections.observe(viewLifecycleOwner, Observer {
                    it.getContentIfNotHandled()?.let { navigateTo(it) }
                })
                isError.observe(viewLifecycleOwner, Observer {
                    it.getContentIfNotHandled()?.let { handleDebugError(it) }
                })
                isLoading.observe(viewLifecycleOwner, Observer { showActivityLoader(it) })
            }
        }
    }

    private fun validateFields() {
        val filledGood = etName.text.toString().isNameValid()
                && etSurname.text.toString().isNameValid()
                && etEmail.text.toString().isMatchEmail()
                && etNumber.text.toString().isNameValid()
                && etPassword.text.toString().isPasswordValid()
                && etPasswordRepeat.text.toString().isPasswordValid()
                && etPassword.text.toString() == etPasswordRepeat.text.toString()
                && cbEula.isChecked
        btnFinishRegistration.setEnableIf(filledGood)
    }
}
