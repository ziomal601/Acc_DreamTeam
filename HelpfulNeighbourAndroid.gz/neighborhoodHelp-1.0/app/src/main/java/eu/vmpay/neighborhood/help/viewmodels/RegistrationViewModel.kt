package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavDirections
import com.amazonaws.mobile.client.results.SignInState
import eu.vmpay.neighborhood.help.models.Address
import eu.vmpay.neighborhood.help.models.PostUserInfo
import eu.vmpay.neighborhood.help.repository.Repository
import eu.vmpay.neighborhood.help.ui.fragments.registration.RegistrationFragmentDirections
import eu.vmpay.neighborhood.help.utils.Event
import kotlinx.coroutines.launch

class RegistrationViewModel(private val repository: Repository) : BaseViewModel() {
    val navDirections = MutableLiveData<Event<NavDirections>>()

    fun createAccount(email: String, password: String, name: String, surname: String, phone: String) {
        isLoading.value = true
        viewModelScope.launch {
            try {
                val signUpResult = repository.signUp(email, password)
                val signInResult = repository.signInWithEmailPassword(email, password)
                if (signInResult.signInState == SignInState.DONE) {
                    repository.postUserInfo(repository.getIdToken(), PostUserInfo(name, surname, phone))
                    // TODO: move putUserInfo & fetchUserInfo to the end of set up account flow
                    repository.putUserInfo(repository.getIdToken(), PostUserInfo(name, surname, phone, 0, isOld = false, isQuarantine = false, address = Address("Baker St", "221B", "00-001", "London")))
                    repository.fetchUserInfo(repository.getIdToken())
                    navDirections.value = if (signUpResult == null)
                        Event(RegistrationFragmentDirections.actionRegistrationFragmentToOnBoardingFragment())
                    else Event(RegistrationFragmentDirections.actionRegistrationFragmentToNumberVerificationFragment(email))
                } else {
                    isError.value = Event(Throwable("${signInResult.signInState}"))
                }
            } catch (e: Exception) {
                isError.value = Event(e)
            } finally {
                isLoading.value = false
            }
        }
    }
}
