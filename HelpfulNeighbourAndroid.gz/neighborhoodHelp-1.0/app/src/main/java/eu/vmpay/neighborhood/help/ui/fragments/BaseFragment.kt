package eu.vmpay.neighborhood.help.ui.fragments

import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.NavDirections
import androidx.navigation.fragment.findNavController
import eu.vmpay.neighborhood.help.BuildConfig
import eu.vmpay.neighborhood.help.MainActivity

abstract class BaseFragment : Fragment() {

    protected fun navigateTo(navDirection: NavDirections) {
        findNavController().navigate(navDirection)
    }

    protected fun goBack() = findNavController().popBackStack()

    protected fun showActivityLoader(shouldShow: Boolean) {
        val activity = activity
        if (activity is MainActivity)
            activity.showLoader(shouldShow)
    }

    protected fun handleDebugError(e: Throwable) {
        if (BuildConfig.DEBUG) {
            e.printStackTrace()
            Toast.makeText(context, "$e", Toast.LENGTH_LONG).show()
        }
    }
}
