package eu.vmpay.neighborhood.help.repository.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import eu.vmpay.neighborhood.help.models.UserInfo
import eu.vmpay.neighborhood.help.models.UserTask
import kotlinx.coroutines.flow.Flow

@Dao
abstract class UserDao : BaseDao<UserInfo>() {

    @Query("SELECT * FROM users")
    abstract fun getUserList(): Flow<List<UserInfo>>

    @Query("SELECT * FROM users")
    abstract suspend fun getUserInfo(): UserInfo?

    @Transaction
    @Query("SELECT * FROM users")
    abstract fun getUserTaskList(): Flow<List<UserTask>>

    @Query("DELETE FROM users")
    abstract suspend fun deleteAll()
}
