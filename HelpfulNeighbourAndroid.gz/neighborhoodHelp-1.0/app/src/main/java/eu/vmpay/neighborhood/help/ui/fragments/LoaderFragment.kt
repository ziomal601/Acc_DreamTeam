package eu.vmpay.neighborhood.help.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.viewmodels.LoaderViewModel
import eu.vmpay.neighborhood.help.viewmodels.ViewModelFactory
import org.koin.android.ext.android.inject

class LoaderFragment : BaseFragment() {
    private val factory: ViewModelFactory by inject()
    private val viewModel: LoaderViewModel by activityViewModels { factory }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
            inflater.inflate(R.layout.loader_fragment, container, false).apply {
                with(viewModel) {
                    navDirection.observe(viewLifecycleOwner, Observer {
                        it.getContentIfNotHandled()?.let { navigateTo(it) }
                    })
                    isError.observe(viewLifecycleOwner, Observer {
                        it.getContentIfNotHandled()?.let { handleDebugError(it) }
                    })
                }
            }
}
