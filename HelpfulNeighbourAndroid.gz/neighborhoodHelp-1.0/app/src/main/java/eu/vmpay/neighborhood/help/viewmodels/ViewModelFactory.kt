package eu.vmpay.neighborhood.help.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import eu.vmpay.neighborhood.help.repository.Repository

@Suppress("UNCHECKED_CAST")
class ViewModelFactory(private val repository: Repository) : ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when (modelClass) {
            DashboardViewModel::class.java -> {
                DashboardViewModel(repository) as T
            }
            LoginViewModel::class.java -> {
                LoginViewModel(repository) as T
            }
            RegistrationViewModel::class.java -> {
                RegistrationViewModel(repository) as T
            }
            NeedHelpFormViewModel::class.java -> {
                NeedHelpFormViewModel() as T
            }
            ShopPaymentsViewModel::class.java -> {
                ShopPaymentsViewModel() as T
            }
            LoaderViewModel::class.java -> {
                LoaderViewModel(repository) as T
            }
            else -> {
                throw IllegalArgumentException("unknown model class $modelClass")
            }
        }
    }
}
