package eu.vmpay.neighborhood.help.viewmodels

import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import eu.vmpay.neighborhood.help.R
import eu.vmpay.neighborhood.help.models.Task

class NeedHelpFormViewModel : BaseViewModel() {

    var task: Task? = null

    fun getTypeID(chipGroup: ChipGroup): Long {
        for (index in 0 until chipGroup.childCount) {
            val chip: Chip = chipGroup.getChildAt(index) as Chip
            if (chip.isChecked) {
                return getID(chip.id)
            }
        }
        return -1
    }

    fun getID(id: Int): Long {
        return when (id) {
            R.id.chipShopping -> 0
            R.id.chipAnimals -> 1
            R.id.chipPharmacy -> 2
            R.id.chipPrivate -> 3
            R.id.chipTransport -> 4
            R.id.chipOther -> 5
            else -> -1
        }
    }

    fun getType(id: Int): Int {
        return when (id) {
            0 -> R.string.shopping
            1 -> R.string.animals
            2 -> R.string.pharmacy
            3 -> R.string.private_lessons
            4 -> R.string.transport
            5 -> R.string.other
            else -> -1
        }

    }
}
