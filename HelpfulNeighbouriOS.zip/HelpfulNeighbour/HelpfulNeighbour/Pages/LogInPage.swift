//
//  LogInPage.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Rswift

struct LogInPage: View {
    
    @State private var email: String = ""
    @State private var password: String = ""
    
    var body: some View {
        NavigationView {
            
            VStack(alignment: .leading) {
                VStack {
                    
                    Image("login_image")
                        .frame(height: 150)
                        .padding(.vertical, 40)
                    
                    VStack {
                        Text("Cześć Sąsiedzie!")
                            .font(.custom("OpenSans-Bold", size: 20))
                            .padding(.bottom, 8)
                        
                        Text("Zaloguj się, aby korzystać z aplikacji.")
                            .font(.custom("OpenSans-Light", size: 16))
                        
                        TextField("Adres e-mail", text: $email)
                            .textFieldStyle(GreyTextFieldStyle())
                            .textContentType(.emailAddress)
                            .padding(.vertical, 10)
                        
                        SecureField("Hasło", text: $password)
                            .textFieldStyle(GreyTextFieldStyle())
                            .textContentType(.password)
                            
                            .padding(.vertical, 10)
                    }
                    
                    Button(action: {
                        print("zapomniałem hasła")
                    }) {
                        Text("Zapomniałeś hasła ?")
                            .font(.custom("OpenSans-Semibold", size: 14))
                            .foregroundColor(Color("pale_orange"))
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        print("zaloguj sie")
                    }) {
                        Text("Zaloguj się")
                    }.buttonStyle(BlueButtonStyle())
                    
                    Text("lub")
                        .padding(.vertical, 16)
                        .font(.custom("OpenSans-Semibold", size: 14))
                    
                    HStack(spacing: 40) {
                        Button(action: {
                            print("google")
                        }) {
                            Text("Google login")
                        }
                        .buttonStyle(GreyButtonStyle())
                        .frame(width: 150)
                        
                        Button(action: {
                            print("facebook")
                        }) {
                            Text("Facebook login")
                        }
                        .buttonStyle(GreyButtonStyle())
                        .frame(width: 130)
                    }
                    
                    NavigationLink(destination: SignUpPage(viewModel: SignUpViewModel())) {
                        Text("Nie masz konta? Zarejestruj się.")
                            .padding(.vertical, 16)
                            .font(.custom("OpenSans-Semibold", size: 14))
                            .foregroundColor(Color("coral"))
                    }
                    
                }.padding(.horizontal, 30)
            }
            .padding(.top, -50)
            .padding(.bottom, 16)
        }
        
        
    }
}

#if DEBUG
struct LogIn_Previews: PreviewProvider {
    static var previews: some View {
        LogInPage()
    }
}
#endif
