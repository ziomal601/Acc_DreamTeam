////
////  DashboardVolunteer.swift
////  HelpfulNeighbour
////
////  Created by Eugene Hyrol on 20/03/2020.
////  Copyright © 2020 HelpfulNeighbour. All rights reserved.
////
//
//import SwiftUI
//
//struct DashboardVolunteer: View {
//    var body: some View {
//        NavigationView{
//
//
//            VStack{
//                HStack{
//                    Text("Hello, Tomek").bold()
//                    Spacer()
//                    Button(action: {
//
//                    }) {
//                        Image(uiImage: R.image.placeholder()!)
//                    }
//                    Button(action: {
//
//                    }) {
//                        Image(uiImage: R.image.placeholder()!)
//                    }
//                }
//                .foregroundColor(Color("pale_orange"))
//                Spacer()
//                RoundedRectangle(cornerRadius: 30, style: .continuous)
//                    .fill(Color("Grey"))
//                    .frame(height: 250)
//                Text("Nie masz jeszcze żadnych aktywnych próśb.")
//                    .foregroundColor(Color("lightish_blue"))
//                Spacer()
//                NavigationLink(destination: HelpFormPage(viewModel: HelpFormViewModel(provider: DashboardPersonInNeedDataProviderMock()))) {
//                    Text("POPROŚ O POMOC")
//                        .fontWeight(.bold)
//                        .font(.title)
//                        .padding(.horizontal, 50)
//                        .padding(.vertical, 14)
//                        .background(Color("lightish_blue"))
//                        .foregroundColor(.white)
//                        .cornerRadius(50)
//                }
//                ZStack(alignment: .topLeading){
//
//                    RoundedRectangle(cornerRadius: 30)
//                        .fill(Color("Grey"))
//                    VStack{
//                        HStack(){
//                            TagView(text: "zakupy")
//                            TagView(text: "auto")
//                        }.padding()
//                        HStack{
//                            Image(uiImage: R.image.placeholder()!)
//                                .frame(width: 50, height: 50)
//                            Text("adadsad")
//                        }
//                    }
//
//                }.frame(height: 156)
//
//
//
//            }.padding()
//        }
//    }
//}
//
