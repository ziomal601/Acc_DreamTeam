//
//  SignUpPage.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct SignUpPage: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    @ObservedObject var viewModel: SignUpViewModel
    
    var tap: some Gesture {
        TapGesture(count: 1)
            .onEnded { _ in self.endEditing(true)}
    }
    
    var body: some View {
        ScrollView {
            
            Text("Załóż konto użytkownika")
                .font(.custom("OpenSans-Bold", size: 20))
                .padding(.bottom, 16)
            
            Text("""
                    Wpisz swoje informacje poniżej
                    abyś mógł rozpocząć korzystanie
                     z aplikacji Pomocny Sąsiad.
                    """)
                .font(.custom("OpenSans-Light", size: 16))
                .multilineTextAlignment(.center)
                .frame(width: 300)
                .padding(.bottom, 8)
            
            VStack {
                TextField("Imię", text: $viewModel.firstName)
                    .textContentType(.name)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
                
                TextField("Nazwisko", text: $viewModel.lastName)
                    .textContentType(.name)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
                
                TextField("E-mail", text: $viewModel.email)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
                
                TextField("Numer Telefonu", text: $viewModel.phoneNumber)
                    .textContentType(.telephoneNumber)
                    .keyboardType(.phonePad)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
                
                SecureField("Hasło (min. 8 znaków)", text: $viewModel.password)
                    .textContentType(.password)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
                
                SecureField("Powtórz hasło", text: $viewModel.passwordConfirmation)
                    .textContentType(.password)
                    .textFieldStyle(GreyTextFieldStyle())
                    .padding(.vertical, 10)
            }
            
            HStack {
                Button(action: {
                    self.viewModel.termsAccepted = !self.viewModel.termsAccepted
                }) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.clear)
                        .frame(width: 20, height: 20)
                        .border(Color("lightish_blue"), width: viewModel.termsAccepted ? 10 : 2.1)
                        .padding(.horizontal, 15)
                }
                
                Text("Akceptacja warunków korzystania")
                    .font(.custom("OpenSans-Regular", size: 14))
            }.padding(.horizontal, 30)
            
            registerButton
            
            Button(action: {
                self.mode.wrappedValue.dismiss()
            }) {
                Text("Powrót do logowania")
                    .font(.custom("OpenSans-Semibold", size: 14))
                    .foregroundColor(Color("coral"))
            }
            
        }
        .padding(.horizontal, 30)
            
        .padding(.top, -64)
        .padding(.bottom, 16)
        .navigationBarItems(leading:
            Button(action: {
                self.mode.wrappedValue.dismiss()
            }) {
                Image("arrow_left")
                    .frame(width: 25, height: 25)
            }
        ).keyboardResponsive()
            .gesture(tap)
        
    }
}

fileprivate extension SignUpPage {
    
    var registerButton: some View {
        let link = NavigationLink(destination: VerifyPage(viewModel: VerifyPageViewModel())) {
            Text("Zarejestruj się")
        }
        .foregroundColor(Color("Grey"))
        .padding(.all, 30)
        .disabled(!viewModel.canContinue)
        
        if viewModel.canContinue {
            return AnyView(link.buttonStyle(BlueButtonStyle()))
        } else {
            return AnyView(link.buttonStyle(GreyButtonStyle()))
        }
    }
}

#if DEBUG
struct SignUp_Previews: PreviewProvider {
    static var previews: some View {
        SignUpPage(viewModel: SignUpViewModel())
    }
}
#endif
