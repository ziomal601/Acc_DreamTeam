//
//  HelpForm.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import ASCollectionView

struct HelpFormPage: View {
    
    @ObservedObject var viewModel: HelpFormViewModel
    
    init(viewModel: HelpFormViewModel) {
        self.viewModel = viewModel
    }
    
    var tap: some Gesture {
        TapGesture(count: 1)
            .onEnded { _ in self.endEditing(true)}
    }
    
    var body: some View {
        ScrollView{
            VStack(alignment: HorizontalAlignment.leading){
                Text("Czego Ci potrzeba?")
                    .bold()
                    .font(Font.system(size: 24))
                    .foregroundColor(Color("pale_orange"))
                Text("Opisz w czym potrzebujesz pomocy. Im więcej informacji tym większa szansa na sprawne znalezienie Wolontariusza.")
                
                
                ASCollectionView(data: viewModel.tags, dataID: \.self) { item, _ in
                    
                    Button(action: {
                        self.viewModel.selectedTag = item
                    }) {
                        CategoryView(text: item, selected: item == self.viewModel.selectedTag)
                    }
                    
                }
                .layout {
                    .grid(layoutMode: .fixedNumberOfColumns(3),
                          itemSpacing: 7,
                          lineSpacing: 7,
                          itemSize: .estimated(40))
                }
                .frame(height: 140)
                
                
                VStack(alignment: .leading, spacing: 0){
                    CheckView(title: "Adres inny niż w moim profilu")
                    CheckView(title: "Prośba dla kogoś innego")
                    CheckView(title: "Potrzebny samochód")
                }
                
                TextField("Tytuł zgłoszenia", text: $viewModel.title)
                    .frame(height: 40)
                    .background(Color("Grey"))
                    .cornerRadius(30)
                    .multilineTextAlignment(.center)
                    .lineLimit(nil)
                
                TextField("Opis zgłoszenia\nNapisz szczegółowo czego dokładnie potrzebujesz. Jeśli są to zakupy, załącz listę potrzebnych produktów.", text: $viewModel.description)
                    .frame( height: 180)
                    .background(Color("Grey"))
                    .cornerRadius(30)
                    .multilineTextAlignment(.center)
                    .lineLimit(nil)
                CheckView(title: "Sprawa pilna")
                //                NavigationLink(destination:Dashboard()) {
                //                    Text("GOTOWE")
                //                        .fontWeight(.bold)
                //                        .font(.title)
                //                        .padding(.horizontal, 50)
                //                        .padding(.vertical, 14)
                //                        .background(Color(viewModel.isValid ? "lightish_blue" : "Grey" ))
                //                        .foregroundColor(.black)
                //                        .cornerRadius(40)
                //
                //                }
                //
                //                .disabled(!viewModel.isValid)
                
                
            }
            .padding()
        }.keyboardResponsive()
            .gesture(tap)
    }
}

private struct CategoryView: View {
    
    let text: String
    let color: Color = Color("Purple")
    let selectedColor: Color = Color("Orange")
    let selected: Bool
    
    init(text: String, selected: Bool = false) {
        self.text = text
        self.selected = selected
    }
    
    var body: some View {
        Text(text.uppercased())
            .fontWeight(.bold)
            .frame(height: 40, alignment: .center)
            .font(.system(size: 12))
            .padding(.horizontal, 20)
            .padding(.vertical, 5)
            .background( selected ? selectedColor : color)
            .foregroundColor(.white)
            .cornerRadius(40)
        
    }
}


struct TextView: UIViewRepresentable {
    
    typealias UIViewType = UITextView
    var configuration = { (view: UIViewType) in }
    
    func makeUIView(context: UIViewRepresentableContext<Self>) -> UIViewType {
        UIViewType()
    }
    
    func updateUIView(_ uiView: UIViewType, context: UIViewRepresentableContext<Self>) {
        configuration(uiView)
    }
}

extension View {
    func endEditing(_ force: Bool) {
        UIApplication.shared.windows.forEach { $0.endEditing(force)}
    }
}
