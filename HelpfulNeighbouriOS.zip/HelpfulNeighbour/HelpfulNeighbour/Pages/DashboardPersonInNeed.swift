//
//  DashboardPersonInNeed.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct DashboardPersonInNeed: View {
    
    @ObservedObject var viewModel: DashboardPersonInNeedViewModel
    
    init(viewModel: DashboardPersonInNeedViewModel) {
        self.viewModel = viewModel
    }
    
    var body: some View {
        NavigationView{
            VStack{
                HStack{
                    Button(action: {
                        
                    }) {
                        Image("menu")
                    }
                    Text("Cześć \(viewModel.name)!")
                        .font(.custom("OpenSans-Bold", size: 16))
                        .padding(.leading, 9)
                    Spacer()
                    Button(action: {
                        
                    }) {
                        Image("bell")
                            .foregroundColor(Color("pale_orange"))
                    }
                    
                }
                .padding(.bottom, 40)
                ScrollView{
                    
                    Spacer()
                    generateMainView()
                }
                
                Spacer()
                NavigationLink(destination: HelpFormPage(viewModel: HelpFormViewModel(provider: DashboardPersonInNeedDataProviderMock()))) {
                    createApplicationButton
                }
            }
            .padding(30)
            .hiddenNavigationBarStyle()
        }
    }
}

extension DashboardPersonInNeed {
    
    private func generateMainView() -> some View {
        if viewModel.applications.count > 0 {
            
            return AnyView(
                VStack(alignment: .leading, spacing: 20){
                    Text("Aktywne zgłoszenia")
                        .font(.custom("OpenSans-Bold", size: 20))
                    ForEach(viewModel.applications, id: \.self.id){
                        DashboardApplicationView(viewModel: $0)
                    }
                }
            )
        }
        return AnyView(placeholderView)
    }
    
    private var placeholderView: some View {
        VStack{
            Image("no_data")
                .frame(height: 250)
                .padding(.bottom, 30)
            Text("Nie masz jeszcze żadnych aktywnych próśb.")
                .foregroundColor(Color("black"))
        }
    }
    
    private var createApplicationButton: some View {
        Text("POPROŚ O POMOC")
            .fontWeight(.bold)
            .font(.custom("OpenSans-Light", size: 16))
            .padding(.horizontal, 40)
            .padding(.vertical, 14)
            .background(Color("lightish_blue"))
            .foregroundColor(.white)
            .cornerRadius(50)
    }
}

struct DashboardApplicationView: View {
    
    @ObservedObject var viewModel: ApplicationViewModel
    
    var body: some View {
        
        RoundedRectangle(cornerRadius: 20)
            .fill(Color("Light Grey"))
            .overlay(
                VStack(alignment: .leading, spacing: 20){
                    HStack(spacing: 10){
                        ForEach(viewModel.tags, id: \.self) {
                            TagView(tag: $0)
                        }
                    }
                    HStack{
                        viewModel.image
                            .frame(width: 55, height: 55)
                            .padding(15)
                            .padding(.trailing, 25)
                        VStack(alignment: .leading, spacing: 6){
                            Text(viewModel.title)
                                .font(.custom("OpenSans-Semibold", size: 14))
                                
                            Text(viewModel.description)
                                .font(.custom("OpenSans", size: 12))
                        }
                        
                    }
                }.padding(20)
        )
            .frame(height: 185)
    }
}

struct HiddenNavigationBar: ViewModifier {
    func body(content: Content) -> some View {
        content
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarHidden(true)
    }
}

extension View {
    func hiddenNavigationBarStyle() -> some View {
        ModifiedContent(content: self, modifier: HiddenNavigationBar())
    }
}
