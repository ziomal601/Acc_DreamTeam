//
//  ProfileChoosePage.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct ProfileChoosePage: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @ObservedObject var viewModel: ProfileChooseViewModel
    
    init(viewModel: ProfileChooseViewModel) {
        self.viewModel = viewModel
    }
    
    var body: some View {
        VStack {
            
            Text("Wybierz typ profilu")
                .font(.custom("OpenSans-Bold", size: 20))
                .padding(.bottom, 16)
            
            Text("""
                        Daj nam znać czy jesteś osobą,
                        która potrzebuje czy osobą chętną
                        do pomocy sąsiadom w potrzebie!
                        """)
                .font(.custom("OpenSans-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.bottom, 15)
            
            Image("profileChoose_image")
                .frame(height: 219)
            
            Spacer()
            
            Button(action: {
                self.viewModel.selectedProfileType = .inNeed
            }) {
                Text("Potrzebuję pomocy")
            }.buttonStyle(SelectionButtonStyle(active: self.viewModel.selectedProfileType == .inNeed))
                .padding(.vertical, 8)
            
            Button(action: {
                self.viewModel.selectedProfileType = .volunteer
            }) {
                Text("Chcę pomóc")
            }.buttonStyle(SelectionButtonStyle(active: self.viewModel.selectedProfileType == .volunteer))
                .padding(.vertical, 8)
            
            continueButton
        }
        .padding(.horizontal, 30)
        .padding(.top, -64)
        .padding(.bottom, 16)
        .navigationBarItems(leading:
            Button(action: {
                self.mode.wrappedValue.dismiss()
            }) {
                Image("arrow_left")
                    .frame(width: 25, height: 25)
            }
        )
    }
}

private extension ProfileChoosePage {
    var continueButton: some View {
        
        var destination: AnyView = AnyView(Text("Implementatiion in rogress..."))
        if let selection = viewModel.selectedProfileType, selection == .inNeed {
            destination = AnyView(DashboardPersonInNeed(viewModel: DashboardPersonInNeedViewModel(provider: DashboardPersonInNeedDataProviderMock())))
        }
        let button = NavigationLink(destination: destination) {
            Text("Kontynuuj")
        }
            .foregroundColor(Color("Grey"))
            .padding(.all, 30)
            .disabled(!viewModel.canContinue)
            
        if viewModel.canContinue {
            return AnyView(button.buttonStyle(BlueButtonStyle()))
        } else {
            return AnyView(button.buttonStyle(GreyButtonStyle()))
        }
    }
}

#if DEBUG
struct ProfileChoose_Previews: PreviewProvider {
    static var previews: some View {
        ProfileChoosePage(viewModel: .init())
    }
}
#endif
