//
//  VerifyPage.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct VerifyPage: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    @ObservedObject var viewModel: VerifyPageViewModel
    
    var tap: some Gesture {
        TapGesture(count: 1)
            .onEnded { _ in self.endEditing(true)}
    }
    
    var body: some View {
        ScrollView {
            
            Text("Weryfikacja numeru telefonu")
                .font(.custom("OpenSans-Bold", size: 20))
                .padding(.bottom, 16)
            
            Text("""
                    Wprowadź kod weryfikacyjny.
                    Został on wysłany na Twój numer telefonu.
                    """)
                .font(.custom("OpenSans-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.bottom, 15)
            
            Image("undraw_verified_tw_20")
                .frame(height: 253)
                .padding(.bottom, 20)
            
            HStack(spacing: 30) {
                makeTextField($viewModel.code0)
                makeTextField($viewModel.code1)
                makeTextField($viewModel.code2)
                makeTextField($viewModel.code3)
                
            }.padding(.top, 50)
            
            Spacer()
            
            verifyButton
            
            Button(action: {
                self.mode.wrappedValue.dismiss()
            }) {
                Text("Wyślij kod ponownie")
                    .font(.custom("OpenSans-Semibold", size: 14))
                    .foregroundColor(Color("Red"))
            }
            
        }
        .padding(.top, -58)
        .padding(.bottom, 16)
        .navigationBarItems(leading:
            Button(action: {
                self.mode.wrappedValue.dismiss()
            }) {
                Image("arrow_left")
                    .frame(width: 25, height: 25)
            }
        )
        .keyboardResponsive()
        .gesture(tap)
    }
    
    
}

private extension VerifyPage {
    func makeTextField(_ text: Binding<String>) -> some View {
        TextField("", text: text)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color("Light Grey"))
                    .frame(width: 60, height: 100)
        )
            .font(.custom("OpenSans-Bold", size: 60))
            .keyboardType(.numberPad)
            .multilineTextAlignment(.center)
            .frame(width: 60, height: 100)
    }
    
    var verifyButton: some View {
        let button = NavigationLink(destination: ProfileChoosePage(viewModel: .init())) {
            Text("Weryfikuj")
        }
            .foregroundColor(Color("Grey"))
                    .padding(.all, 30)
                    .disabled(!viewModel.canContinue)
            
        if viewModel.canContinue {
            return AnyView(button.buttonStyle(BlueButtonStyle()))
        } else {
            return AnyView(button.buttonStyle(GreyButtonStyle()))
        }
    }
}

#if DEBUG
struct Verify_Previews: PreviewProvider {
    static var previews: some View {
        VerifyPage(viewModel: VerifyPageViewModel())
    }
}
#endif
