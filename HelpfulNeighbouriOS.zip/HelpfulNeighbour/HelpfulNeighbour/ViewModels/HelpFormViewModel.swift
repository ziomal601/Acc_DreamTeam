//
//  HelpFormViewModel.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Combine

class HelpFormViewModel: ObservableObject, Identifiable {
  
    let tags: [String] = HelpType.allCases.map{ HelpTag(type: $0).title }
    
    var isValid: Bool {
        return !title.isEmpty && !description.isEmpty && selectedTag != nil
    }
    
    @Published var description: String = ""

    @Published var title: String = ""
    
    @Published var selectedTag: String?
    
    @Published var applications = [ApplicationViewModel]()
        
    private let provider: DashboardPersonInNeedDataProviderProtocol
    private var disposables = Set<AnyCancellable>()

    init(provider: DashboardPersonInNeedDataProviderProtocol) {
        self.provider = provider
        provider.applications()
            .sink(receiveCompletion: { result in
            
            }, receiveValue: { applications in
                self.applications = applications.map{ ApplicationViewModel(application: $0) }
            })
            .store(in: &disposables)
    }
}

struct HelpTag: Hashable {
    
    let title: String
    let color: Color
    
    static let urgent = HelpTag(title: "Pilne", color: Color("tomato"))
}

extension HelpTag {
    init(type: HelpType) {
        switch type {
        case .grocery:
            self.title = "Zakupy"
            self.color = Color("lightish_blue")
        case .lessons:
            self.title = "Korepetycje"
            self.color = Color("purpley")
        case .medicine:
            self.title = "Apteka"
            self.color = Color("coral")
        case .pets:
            self.title = "Zwierzęta"
            self.color = Color("pale_orange")
        case .transport:
            self.title = "Transport"
            self.color = Color("boring_green")
        case .other:
            self.title = "Inne"
            self.color = Color("cobalt")
        }
    }
}

enum HelpType: Int, Codable, CaseIterable {
    case grocery
    case pets
    case medicine
    case lessons
    case transport
    case other
}
