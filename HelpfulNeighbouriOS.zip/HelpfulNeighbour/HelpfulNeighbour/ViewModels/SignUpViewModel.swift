//
//  SignUpViewModel.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Combine

class SignUpViewModel: ObservableObject, Identifiable {
    
    @Published var firstName = String()
    @Published var lastName = String()
    @Published var email = String()
    @Published var phoneNumber = String()
    @Published var password = String()
    @Published var passwordConfirmation = String()
    @Published var termsAccepted = false
    
    var canContinue: Bool {
        return !firstName.isEmpty && !lastName.isEmpty && !email.isEmpty && !phoneNumber.isEmpty && !password.isEmpty && password.count >= 8 && password == passwordConfirmation && termsAccepted
    }
    
}
