//
//  ProfileChooseViewModel.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 22/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Combine

class ProfileChooseViewModel: ObservableObject, Identifiable {
    
    @Published var selectedProfileType: ProfileType?
    
    var canContinue: Bool {
        return selectedProfileType != nil
    }
}

enum ProfileType: Hashable {
    case volunteer
    case inNeed
    case unknown
}
