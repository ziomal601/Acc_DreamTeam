//
//  VerifyPageViewModel.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 22/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Combine

class VerifyPageViewModel: ObservableObject, Identifiable {
    
    @Published var code0 = String()
    @Published var code1 = String()
    @Published var code2 = String()
    @Published var code3 = String()
    
    var canContinue: Bool {
        return !code0.isEmpty && !code1.isEmpty && !code2.isEmpty && !code3.isEmpty
    }
}
