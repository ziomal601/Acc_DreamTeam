//
//  DashboardPersonInNeedViewModel.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI
import Combine

class DashboardPersonInNeedViewModel: ObservableObject, Identifiable {
  
    @Published var name: String = "Tomek"
    
    @Published var applications: [ApplicationViewModel] = []
    
    let dashboardDataProvider: DashboardPersonInNeedDataProviderProtocol
    private var disposables = Set<AnyCancellable>()

   init(provider: DashboardPersonInNeedDataProviderProtocol) {
        self.dashboardDataProvider = provider
        dashboardDataProvider.applications()
            .sink(receiveCompletion: { result in
            
            }, receiveValue: { applications in
                self.applications = applications.map{ ApplicationViewModel(application: $0) }
            })
            .store(in: &disposables)
    }
}

class ApplicationViewModel: ObservableObject, Identifiable {
    
    let tags: [HelpTag]
    let title: String
    let description: String
    var image: Image {
        switch model.helpType {
        case .grocery: return Image("help_type_grocery")
        case .lessons: return Image("help_type_study")
        case .medicine: return Image("help_type_medicine")
        case .pets: return Image("help_type_pets")
        case .transport: return Image("help_type_transport")
        case .other: return Image("help_type_other")
        }
    }
    private let model: ApplicationDTO
    
    init(application: ApplicationDTO) {
        self.model = application
        var tags = [HelpTag]()
        if application.urgent {
            tags.append(HelpTag.urgent)
        }
        tags.append(HelpTag(type: application.helpType))
        self.tags = tags
        self.title = application.title
        self.description = application.description
    }
}

protocol DashboardPersonInNeedDataProviderProtocol {
    
    func applications() -> AnyPublisher<[ApplicationDTO], Error>
}

class DashboardPersonInNeedDataProviderMock: DashboardPersonInNeedDataProviderProtocol {
    
    func applications() -> AnyPublisher<[ApplicationDTO], Error> {
        
        let application1 = ApplicationDTO(id: "123", title: "Duże zakupy",
                                         description: """
Jestem obecnie w kwarantannie i potrzebuje pomocy w zrobieniu większych zakupów spożywczych. Zakładam, że potrzebne będzie auto. Lista zakupów:
        - kasza gryczana
        - cukinia
        - bataty
        - sałata
        - pomidory
        …
"""
            ,
            
                                         helpType: .pets,
                                         reporterId: "3",
                                         status: "Active",
                                         otherAddress: false,
                                         applicationForAnotherPerson: false,
                                         requiresVehicle: true, urgent: true)
        let application2 = ApplicationDTO(id: "123", title: "Duże zakupy",
                                                 description: """
        Jestem obecnie w kwarantannie i potrzebuje pomocy w zrobieniu większych zakupów spożywczych. Zakładam, że potrzebne będzie auto. Lista zakupów:
                - kasza gryczana
                - cukinia
                - bataty
                - sałata
                - pomidory
                …
        """
                    ,
                    
                                                 helpType: .lessons,
                                                 reporterId: "3",
                                                 status: "Active",
                                                 otherAddress: false,
                                                 applicationForAnotherPerson: false,
                                                 requiresVehicle: true, urgent: false)
        return Just([application1, application2])
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
}

struct ApplicationDTO: Codable {
    
    let id: String
    let title: String
    let description: String
    let helpType: HelpType
    let reporterId: String
    let status: String
    let otherAddress: Bool
    let applicationForAnotherPerson: Bool
    let requiresVehicle: Bool
    let urgent: Bool
}

