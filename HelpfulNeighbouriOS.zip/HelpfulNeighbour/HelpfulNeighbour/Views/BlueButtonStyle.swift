//
//  BlueButtonStyle.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct BlueButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .multilineTextAlignment(.center)
            .background(
                RoundedRectangle(cornerRadius: 35)
                    .fill(Color("lightish_blue"))
                    .frame(height: 50)
                    .padding(.horizontal, -60)
                    .padding(.vertical, -14)
            )
            .frame(height: 50)
            .foregroundColor(Color.white)
            .font(.custom("OpenSans-SemiBold", size: 16))
            .animation(.easeInOut)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
