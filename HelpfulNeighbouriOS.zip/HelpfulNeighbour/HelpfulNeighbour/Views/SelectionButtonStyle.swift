//
//  SelectionButtonStyle.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct SelectionButtonStyle: ButtonStyle {
    
    var verticalPadding: CGFloat = -14
    var horizontalPadding: CGFloat = -30
    var cornerRadius: CGFloat = 35
    var height: CGFloat = 50
    var foregroundColor: Color = .black
    
    @State var active: Bool = false
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color(active ? "pale_orange" : "Light Grey"))
                    .frame(width: 360, height: height)
                    .padding(.vertical, verticalPadding)
                    .padding(.horizontal, horizontalPadding)
            )
            .frame(width: 360, height: height)
            .foregroundColor(active ? .white : foregroundColor)
            .font(.custom("OpenSans-SemiBold", size: 16))
            .animation(.easeInOut)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
