//
//  TagView.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct TagView: View {
    let text: String
    let color: Color
    
    init(tag: HelpTag) {
        self.text = tag.title
        self.color = tag.color
    }
    
    var body: some View {
        Text(text.uppercased())
            .fontWeight(.bold)
            .frame(height: 16, alignment: .center)
            .font(.system(size: 10))
            .padding(.horizontal, 20)
            .padding(.vertical, 5)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(50)
    }
}
