//
//  GreyButtonStyle.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct BlueButtonStyle: ButtonStyle {
    
    let verticalPadding: CGFloat = -14
    let horizontalPadding: CGFloat = -30
    let cornerRadius: CGFloat = 35
    let height: CGFloat = 50
    let foregroundColor: Color = Color.white
    let backgroundColor: Color = Color("lightish_blue")
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .multilineTextAlignment(.center)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(backgroundColor)
                    .frame(height: height)
                    .padding(.vertical, verticalPadding)
                    .padding(.horizontal, horizontalPadding)
            )
            .frame(height: height)
            .foregroundColor(foregroundColor)
            .font(.custom("OpenSans-SemiBold", size: 16))
            .animation(.easeInOut)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}

struct GreyButtonStyle: ButtonStyle {
    
    let verticalPadding: CGFloat = -14
    let horizontalPadding: CGFloat = -30
    let cornerRadius: CGFloat = 35
    let height: CGFloat = 50
    let foregroundColor: Color = Color.black
    let backgroundColor: Color = Color("very_light_pink")
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .multilineTextAlignment(.center)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(backgroundColor)
                    .frame(height: height)
                    .padding(.vertical, verticalPadding)
                    .padding(.horizontal, horizontalPadding)
            )
            .frame(height: height)
            .foregroundColor(foregroundColor)
            .font(.custom("OpenSans-SemiBold", size: 16))
            .animation(.easeInOut)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}

struct OrangeButtonStyle: ButtonStyle {
    
    let verticalPadding: CGFloat = -14
    let horizontalPadding: CGFloat = -30
    let cornerRadius: CGFloat = 35
    let height: CGFloat = 50
    let foregroundColor: Color = Color.white
    let backgroundColor: Color = Color("pale_orange")
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .multilineTextAlignment(.center)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(backgroundColor)
                    .frame(height: height)
                    .padding(.vertical, verticalPadding)
                    .padding(.horizontal, horizontalPadding)
            )
            .frame(height: height)
            .foregroundColor(foregroundColor)
            .font(.custom("OpenSans-SemiBold", size: 16))
            .animation(.easeInOut)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
