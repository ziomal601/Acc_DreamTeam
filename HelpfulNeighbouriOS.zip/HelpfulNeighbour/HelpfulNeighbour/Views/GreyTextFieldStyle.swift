//
//  GreyTextFieldStyle.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct GreyTextFieldStyle : TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .multilineTextAlignment(.leading)
            .padding(.leading, 20)
            .disableAutocorrection(true)
            .background(
                RoundedRectangle(cornerRadius: 9)
                    .fill(Color("Light Grey"))
                    .frame(height: 50)
            )
            .frame(height: 50)
            .foregroundColor(Color.black)
            .font(.custom("OpenSans-Light", size: 16))
    }
}


