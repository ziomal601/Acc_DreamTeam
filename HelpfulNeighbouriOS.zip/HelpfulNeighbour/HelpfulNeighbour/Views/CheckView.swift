//
//  CheckView.swift
//  HelpfulNeighbour
//
//  Created by Eugene Hyrol on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import SwiftUI

struct CheckView: View {
    @State var isChecked:Bool = false
    var title:String
    func toggle(){isChecked = !isChecked}
    
    var body: some View {
        Button(action: toggle){
            HStack{
                (isChecked ? RoundedRectangle(cornerRadius: 1.6).fill(Color("pale_orange")) : RoundedRectangle(cornerRadius: 1.6)
                    .fill(Color.green))
                    .frame(width: 16, height: 16)
                
                Text(title)
                    .padding()
                
            }
        }
    }
}
