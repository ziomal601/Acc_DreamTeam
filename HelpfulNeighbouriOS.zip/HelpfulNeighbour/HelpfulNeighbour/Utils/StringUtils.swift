//
//  StringUtils.swift
//  HelpfulNeighbour
//
//  Created by adrian.szymanowski on 21/03/2020.
//  Copyright © 2020 HelpfulNeighbour. All rights reserved.
//

import Foundation

class StringUtils: NSObject {
    class func isNilOrEmpty(_ testString: String?) -> Bool {
        if testString == nil {
            return true
        }
        if testString!.trimmingCharacters(in: .whitespaces).isEmpty {
            return true
        }
        
        return false
    }
    
    class func atLeastOne_NilOrEmpty(_ testStrings: String?...) -> Bool {
        testStrings
            .compactMap { $0 }
            .allSatisfy { $0.trimmingCharacters(in: .whitespaces).isEmpty }
    }
    
    class func areNotNilOrEmpty(_ testStrings: String?...) -> Bool {
        testStrings
            .compactMap { $0 }
            .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.count == testStrings.count
    }
    
    
}
